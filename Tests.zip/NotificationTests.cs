﻿using Platform.Models;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Platform.Tests
{
    [TestClass]
    public class NotificationTests
    {
        [TestMethod]
        public void MarkAsRead_SetsIsReadToTrue()
        {
            var recipient = new Student("login", "pass", "email@test.com", "Name", "Group");

            var notification = new NotificationMessage(recipient, "Test Title", "Test Message");

            notification.MarkAsRead();

            Assert.IsTrue(notification.IsRead, "Сповіщення має бути позначене як прочитане.");
        }

        [TestMethod]
        public void MarkAsRead_AlreadyRead_StaysTrue()
        {
            var recipient = new Student("login", "pass", "email@test.com", "Name", "Group");
            var notification = new NotificationMessage(recipient, "Test Title", "Test Message");

            notification.MarkAsRead();

            notification.MarkAsRead();

            Assert.IsTrue(notification.IsRead, "Сповіщення має залишитися прочитаним.");
        }
    }
}